import matplotlib.pyplot as plt
import cv2
class_labels={
    15:'person',
    2:'cat',
    12:'dog',
    4:'motorbike',
    5:'sheep',
    7:'car'
}
image_path = "Photo.jpg"
image = cv2.imread(image_path)
model_path = r"D:\Machine learning\MobileNetSSD_deploy.prototxt"
weights_path =r"D:\Machine learning\MobileNetSSD_deploy.caffemodel"
net = cv2.dnn.readNet(model_path,weights_path)
img_resized=cv2.resize(image,(300,300))
blob = cv2.dnn.blobFromImage(img_resized,0.007843, (300, 300), (127.5, 127.5, 127.5), False)
net.setInput(blob)
detections=net.forward()
final=detections.squeeze()
print(final)
font=cv2.FONT_HERSHEY_SIMPLEX
height,width,x=image.shape
ig=cv2.imread("Photo.jpg")
for i in range(final.shape[0]):
    conf=final[i,2]
    if conf>0.5:
        class_names=class_labels[final[i,1]]
        x1n,y1n,x2n,y2n=final[i,3:]
        x1=int(x1n*width)
        x2=int(x2n*width)
        y1=int(y1n*height)
        y2=int(y2n*height)
        top_left=(x1,y1)
        bottom_right=(x2,y2)
        ig=cv2.rectangle(ig,top_left,bottom_right,(0,255,0),3)
        ig=cv2.putText(ig,class_names,(x1,y1-10),font,0.5,(255,0,0),1,cv2.LINE_AA)
plt.imshow(ig)
plt.show()
